﻿namespace Voronoi
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.listView_inputedData = new System.Windows.Forms.ListView();
            this.button_inputByClick = new System.Windows.Forms.Button();
            this.button_inputByFile = new System.Windows.Forms.Button();
            this.panel_canvas = new System.Windows.Forms.Panel();
            this.label_mouseX = new System.Windows.Forms.Label();
            this.label_mouseY = new System.Windows.Forms.Label();
            this.groupBox_inputType = new System.Windows.Forms.GroupBox();
            this.groupBox_mouseLocation = new System.Windows.Forms.GroupBox();
            this.button_clear = new System.Windows.Forms.Button();
            this.groupBox_executeType = new System.Windows.Forms.GroupBox();
            this.button_stepBystep = new System.Windows.Forms.Button();
            this.button_Run = new System.Windows.Forms.Button();
            this.button_output = new System.Windows.Forms.Button();
            this.groupBox_InputedData = new System.Windows.Forms.GroupBox();
            this.listView_inputedLine = new System.Windows.Forms.ListView();
            this.button_continue = new System.Windows.Forms.Button();
            this.button_convexhull = new System.Windows.Forms.Button();
            this.groupBox_inputType.SuspendLayout();
            this.groupBox_mouseLocation.SuspendLayout();
            this.groupBox_executeType.SuspendLayout();
            this.groupBox_InputedData.SuspendLayout();
            this.SuspendLayout();
            // 
            // listView_inputedData
            // 
            this.listView_inputedData.Location = new System.Drawing.Point(14, 28);
            this.listView_inputedData.Name = "listView_inputedData";
            this.listView_inputedData.Size = new System.Drawing.Size(287, 106);
            this.listView_inputedData.TabIndex = 0;
            this.listView_inputedData.UseCompatibleStateImageBehavior = false;
            this.listView_inputedData.View = System.Windows.Forms.View.Details;
            // 
            // button_inputByClick
            // 
            this.button_inputByClick.AutoSize = true;
            this.button_inputByClick.Font = new System.Drawing.Font("新細明體", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_inputByClick.Location = new System.Drawing.Point(23, 35);
            this.button_inputByClick.Margin = new System.Windows.Forms.Padding(6);
            this.button_inputByClick.Name = "button_inputByClick";
            this.button_inputByClick.Size = new System.Drawing.Size(145, 37);
            this.button_inputByClick.TabIndex = 2;
            this.button_inputByClick.Text = "點擊畫面輸入";
            this.button_inputByClick.UseVisualStyleBackColor = true;
            // 
            // button_inputByFile
            // 
            this.button_inputByFile.AutoSize = true;
            this.button_inputByFile.Font = new System.Drawing.Font("新細明體", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_inputByFile.Location = new System.Drawing.Point(180, 35);
            this.button_inputByFile.Margin = new System.Windows.Forms.Padding(6);
            this.button_inputByFile.Name = "button_inputByFile";
            this.button_inputByFile.Size = new System.Drawing.Size(121, 37);
            this.button_inputByFile.TabIndex = 3;
            this.button_inputByFile.Text = "選擇檔案";
            this.button_inputByFile.UseVisualStyleBackColor = true;
            this.button_inputByFile.Click += new System.EventHandler(this.button_inputByFile_Click);
            // 
            // panel_canvas
            // 
            this.panel_canvas.BackColor = System.Drawing.SystemColors.Window;
            this.panel_canvas.ForeColor = System.Drawing.SystemColors.Window;
            this.panel_canvas.Location = new System.Drawing.Point(25, 25);
            this.panel_canvas.Name = "panel_canvas";
            this.panel_canvas.Size = new System.Drawing.Size(700, 700);
            this.panel_canvas.TabIndex = 5;
            this.panel_canvas.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel_canvas_MouseDown);
            this.panel_canvas.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel_canvas_MouseMove);
            // 
            // label_mouseX
            // 
            this.label_mouseX.AutoSize = true;
            this.label_mouseX.Font = new System.Drawing.Font("新細明體", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_mouseX.Location = new System.Drawing.Point(19, 32);
            this.label_mouseX.Name = "label_mouseX";
            this.label_mouseX.Size = new System.Drawing.Size(41, 19);
            this.label_mouseX.TabIndex = 7;
            this.label_mouseX.Text = "X：";
            // 
            // label_mouseY
            // 
            this.label_mouseY.AutoSize = true;
            this.label_mouseY.Font = new System.Drawing.Font("新細明體", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_mouseY.Location = new System.Drawing.Point(176, 32);
            this.label_mouseY.Name = "label_mouseY";
            this.label_mouseY.Size = new System.Drawing.Size(41, 19);
            this.label_mouseY.TabIndex = 8;
            this.label_mouseY.Text = "Y：";
            // 
            // groupBox_inputType
            // 
            this.groupBox_inputType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_inputType.Controls.Add(this.button_inputByClick);
            this.groupBox_inputType.Controls.Add(this.button_inputByFile);
            this.groupBox_inputType.Font = new System.Drawing.Font("新細明體", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox_inputType.Location = new System.Drawing.Point(750, 19);
            this.groupBox_inputType.Name = "groupBox_inputType";
            this.groupBox_inputType.Size = new System.Drawing.Size(315, 91);
            this.groupBox_inputType.TabIndex = 9;
            this.groupBox_inputType.TabStop = false;
            this.groupBox_inputType.Text = "輸入資料的方式";
            // 
            // groupBox_mouseLocation
            // 
            this.groupBox_mouseLocation.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_mouseLocation.Controls.Add(this.label_mouseX);
            this.groupBox_mouseLocation.Controls.Add(this.label_mouseY);
            this.groupBox_mouseLocation.Font = new System.Drawing.Font("新細明體", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox_mouseLocation.Location = new System.Drawing.Point(750, 123);
            this.groupBox_mouseLocation.Name = "groupBox_mouseLocation";
            this.groupBox_mouseLocation.Size = new System.Drawing.Size(315, 67);
            this.groupBox_mouseLocation.TabIndex = 10;
            this.groupBox_mouseLocation.TabStop = false;
            this.groupBox_mouseLocation.Text = "滑鼠指標位置";
            // 
            // button_clear
            // 
            this.button_clear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_clear.Font = new System.Drawing.Font("新細明體", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_clear.Location = new System.Drawing.Point(750, 631);
            this.button_clear.Margin = new System.Windows.Forms.Padding(6);
            this.button_clear.Name = "button_clear";
            this.button_clear.Size = new System.Drawing.Size(315, 40);
            this.button_clear.TabIndex = 11;
            this.button_clear.Text = "清空畫布";
            this.button_clear.UseVisualStyleBackColor = true;
            this.button_clear.Click += new System.EventHandler(this.button_clear_Click);
            // 
            // groupBox_executeType
            // 
            this.groupBox_executeType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_executeType.Controls.Add(this.button_convexhull);
            this.groupBox_executeType.Controls.Add(this.button_stepBystep);
            this.groupBox_executeType.Controls.Add(this.button_Run);
            this.groupBox_executeType.Font = new System.Drawing.Font("新細明體", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox_executeType.Location = new System.Drawing.Point(750, 524);
            this.groupBox_executeType.Margin = new System.Windows.Forms.Padding(6);
            this.groupBox_executeType.Name = "groupBox_executeType";
            this.groupBox_executeType.Size = new System.Drawing.Size(315, 90);
            this.groupBox_executeType.TabIndex = 12;
            this.groupBox_executeType.TabStop = false;
            this.groupBox_executeType.Text = "執行模式";
            // 
            // button_stepBystep
            // 
            this.button_stepBystep.AutoSize = true;
            this.button_stepBystep.Location = new System.Drawing.Point(103, 34);
            this.button_stepBystep.Margin = new System.Windows.Forms.Padding(6);
            this.button_stepBystep.Name = "button_stepBystep";
            this.button_stepBystep.Size = new System.Drawing.Size(110, 37);
            this.button_stepBystep.TabIndex = 1;
            this.button_stepBystep.Text = "步驟解析";
            this.button_stepBystep.UseVisualStyleBackColor = true;
            this.button_stepBystep.Click += new System.EventHandler(this.button_stepBystep_Click);
            // 
            // button_Run
            // 
            this.button_Run.AutoSize = true;
            this.button_Run.Location = new System.Drawing.Point(16, 34);
            this.button_Run.Margin = new System.Windows.Forms.Padding(6);
            this.button_Run.Name = "button_Run";
            this.button_Run.Size = new System.Drawing.Size(74, 37);
            this.button_Run.TabIndex = 0;
            this.button_Run.Text = "執行";
            this.button_Run.UseVisualStyleBackColor = true;
            this.button_Run.Click += new System.EventHandler(this.button_Run_Click);
            // 
            // button_output
            // 
            this.button_output.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_output.AutoSize = true;
            this.button_output.Font = new System.Drawing.Font("新細明體", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_output.Location = new System.Drawing.Point(750, 687);
            this.button_output.Margin = new System.Windows.Forms.Padding(6);
            this.button_output.Name = "button_output";
            this.button_output.Size = new System.Drawing.Size(315, 37);
            this.button_output.TabIndex = 13;
            this.button_output.Text = "輸出檔案";
            this.button_output.UseVisualStyleBackColor = true;
            this.button_output.Click += new System.EventHandler(this.button_output_Click);
            // 
            // groupBox_InputedData
            // 
            this.groupBox_InputedData.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_InputedData.Controls.Add(this.listView_inputedLine);
            this.groupBox_InputedData.Controls.Add(this.button_continue);
            this.groupBox_InputedData.Controls.Add(this.listView_inputedData);
            this.groupBox_InputedData.Font = new System.Drawing.Font("新細明體", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox_InputedData.Location = new System.Drawing.Point(750, 205);
            this.groupBox_InputedData.Margin = new System.Windows.Forms.Padding(6);
            this.groupBox_InputedData.Name = "groupBox_InputedData";
            this.groupBox_InputedData.Size = new System.Drawing.Size(315, 305);
            this.groupBox_InputedData.TabIndex = 14;
            this.groupBox_InputedData.TabStop = false;
            this.groupBox_InputedData.Text = "已輸入資料";
            // 
            // listView_inputedLine
            // 
            this.listView_inputedLine.Location = new System.Drawing.Point(14, 143);
            this.listView_inputedLine.Name = "listView_inputedLine";
            this.listView_inputedLine.Size = new System.Drawing.Size(287, 106);
            this.listView_inputedLine.TabIndex = 2;
            this.listView_inputedLine.UseCompatibleStateImageBehavior = false;
            this.listView_inputedLine.View = System.Windows.Forms.View.Details;
            // 
            // button_continue
            // 
            this.button_continue.AutoSize = true;
            this.button_continue.Location = new System.Drawing.Point(14, 259);
            this.button_continue.Margin = new System.Windows.Forms.Padding(6);
            this.button_continue.Name = "button_continue";
            this.button_continue.Size = new System.Drawing.Size(287, 37);
            this.button_continue.TabIndex = 1;
            this.button_continue.Text = "繼續讀取下一組測資";
            this.button_continue.UseVisualStyleBackColor = true;
            this.button_continue.Click += new System.EventHandler(this.button_continue_Click);
            // 
            // button_convexhull
            // 
            this.button_convexhull.Location = new System.Drawing.Point(225, 34);
            this.button_convexhull.Margin = new System.Windows.Forms.Padding(6);
            this.button_convexhull.Name = "button_convexhull";
            this.button_convexhull.Size = new System.Drawing.Size(75, 37);
            this.button_convexhull.TabIndex = 2;
            this.button_convexhull.Text = "凸包";
            this.button_convexhull.UseVisualStyleBackColor = true;
            this.button_convexhull.Click += new System.EventHandler(this.button_convexhull_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1082, 753);
            this.Controls.Add(this.groupBox_InputedData);
            this.Controls.Add(this.button_output);
            this.Controls.Add(this.groupBox_executeType);
            this.Controls.Add(this.button_clear);
            this.Controls.Add(this.groupBox_mouseLocation);
            this.Controls.Add(this.groupBox_inputType);
            this.Controls.Add(this.panel_canvas);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Voronoi_M083040003";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox_inputType.ResumeLayout(false);
            this.groupBox_inputType.PerformLayout();
            this.groupBox_mouseLocation.ResumeLayout(false);
            this.groupBox_mouseLocation.PerformLayout();
            this.groupBox_executeType.ResumeLayout(false);
            this.groupBox_executeType.PerformLayout();
            this.groupBox_InputedData.ResumeLayout(false);
            this.groupBox_InputedData.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listView_inputedData;
        private System.Windows.Forms.Button button_inputByClick;
        private System.Windows.Forms.Button button_inputByFile;
        private System.Windows.Forms.Label label_mouseX;
        private System.Windows.Forms.Label label_mouseY;
        private System.Windows.Forms.GroupBox groupBox_inputType;
        private System.Windows.Forms.GroupBox groupBox_mouseLocation;
        private System.Windows.Forms.Button button_clear;
        public System.Windows.Forms.Panel panel_canvas;
        private System.Windows.Forms.GroupBox groupBox_executeType;
        private System.Windows.Forms.Button button_stepBystep;
        private System.Windows.Forms.Button button_Run;
        private System.Windows.Forms.Button button_output;
        private System.Windows.Forms.GroupBox groupBox_InputedData;
        private System.Windows.Forms.Button button_continue;
        private System.Windows.Forms.ListView listView_inputedLine;
        private System.Windows.Forms.Button button_convexhull;
    }
}

