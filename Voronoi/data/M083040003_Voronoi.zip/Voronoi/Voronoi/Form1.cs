﻿//  $LAN=C#$
//  M083040003 郭怡華 I-HUA, KUO
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using System.Collections;

namespace Voronoi
{
    public partial class Form1 : Form
    {
        string[] point = { "X-position", "Y-position" };
        Graphics canvas;
        OpenFileDialog open_dialog;
        SaveFileDialog save_dialog;
                
        bool pauseReadFile = false;
        bool pauseStep = false;
        bool pauseConvex = false;

        bool endStep = true;
        bool endConvex = true;
        bool StepMode = false;//是否為StepbysStep模式
        
        int alreadyRead = 0;//紀錄目前的檔案已讀取了幾行
       
        Pen Red_pen = new Pen(Color.Red, 5);
        Pen Yellow_pen = new Pen(Color.Yellow, 5);        
        Pen Black_pen = new Pen(Color.Black, 5);
        Pen Gainsboro_pen = new Pen(Color.Gainsboro, 3); //畫ConvexHull
        Pen LightSkyBlue_pen = new Pen(Color.LightSkyBlue, 5);
        Pen LightSalmon_pen = new Pen(Color.LightSalmon, 5);        
        
        Thread thread;
        Thread thread_convex;
       
        public Form1()
        {
            InitializeComponent();
            Form.CheckForIllegalCrossThreadCalls = false;            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Size = new Size(1100, 800);
            this.MinimumSize = new Size(1100, 800);
            panel_canvas.Size = new Size(700, 700);
            canvas = panel_canvas.CreateGraphics();
            listView_inputedData.Columns.Add("X");
            listView_inputedData.Columns.Add("Y");
            listView_inputedLine.Columns.Add("x1");
            listView_inputedLine.Columns.Add("y1");
            listView_inputedLine.Columns.Add("x2");
            listView_inputedLine.Columns.Add("y2");
            button_Run.Enabled = false;
            button_stepBystep.Enabled = false;
            button_continue.Enabled = false;
            button_convexhull.Enabled = false;
        }

        private void panel_canvas_MouseMove(object sender, MouseEventArgs e)
        {
            label_mouseX.Text ="X：" + e.X.ToString();
            label_mouseY.Text ="Y：" + e.Y.ToString();
        }

        private void panel_canvas_MouseDown(object sender, MouseEventArgs e)
        {
            if (button_inputByClick.Enabled == true)
            {
                button_Run.Enabled = true;
                button_stepBystep.Enabled = true;
                button_convexhull.Enabled = true;
                button_inputByFile.Enabled = false;
                button_continue.Enabled = false;

                string pointX, pointY;
                pointX = e.X.ToString();
                pointY = e.Y.ToString();

                int x, y;
                x = Int32.Parse(pointX);
                y = Int32.Parse(pointY);

                string[] coordinate = { pointX, pointY };
                var AddPoint = new ListViewItem(coordinate);
                listView_inputedData.Items.Add(AddPoint);

                DrawPoint(x, y);
            }          
        }

        private void DrawPoint(int x, int y)
        {
            Pen pen = new Pen(Color.Black, 5);
            canvas.DrawEllipse(pen, x, y, 5, 5);  
        }

        //清除畫布、點和線的紀錄
        private void button_clear_Click(object sender, EventArgs e)
        {
            canvas.Clear(Color.White);
            listView_inputedData.Items.Clear();
            listView_inputedData.Refresh();
            listView_inputedLine.Items.Clear();
            listView_inputedLine.Refresh();
            button_Run.Enabled = true;
            button_stepBystep.Enabled = true;
            button_convexhull.Enabled = true;
            
            endStep = true;
            if (thread != null) { thread.Abort(); thread.Join(); }
            endConvex = true;
            if (thread_convex != null) { thread_convex.Abort(); thread_convex.Join(); }
            
            if (alreadyRead == 0)
            {                
                button_inputByFile.Enabled = true;
                button_inputByClick.Enabled = true;                
                button_continue.Enabled = false;                
            }
            //若檔案讀取到一半
            else {
                
                button_inputByFile.Enabled = false;
                button_inputByClick.Enabled = false;                
                button_continue.Enabled = true;
                MessageBox.Show("檔案尚未讀取完畢!");
            }
        }

        private void button_inputByFile_Click(object sender, EventArgs e)
        {
            button_inputByClick.Enabled = false;
            open_dialog = new OpenFileDialog();
            open_dialog.Title = "Select File";
            open_dialog.InitialDirectory = ".\\";
            open_dialog.Filter = "Text Files (*.txt)|*.txt|All files (*.*)|*.*";
            if (open_dialog.ShowDialog() == DialogResult.OK)
            {
                MessageBox.Show(open_dialog.FileName);                
                ReadFile();
            }
        }

        private void button_output_Click(object sender, EventArgs e)
        {
            save_dialog = new SaveFileDialog();
            save_dialog.Title = "Output File";
            save_dialog.InitialDirectory = @"c:\desktop";
            save_dialog.Filter = "Text Files (*.txt)|*.txt|All files (*.*)|*.*";

            DialogResult result = save_dialog.ShowDialog();
            if (result == DialogResult.OK)
            {
                System.IO.StreamWriter file = new System.IO.StreamWriter(save_dialog.FileName);
                if (!File.Exists(save_dialog.FileName))
                {
                    File.Create(save_dialog.FileName);
                }

                for (int i = 0; i < listView_inputedData.Items.Count; i++)
                {
                    ListViewItem item = listView_inputedData.Items[i];
                    file.WriteLine(String.Format("P {0} {1}", item.SubItems[0].Text, item.SubItems[1].Text));
                }

                for (int i = 0; i < listView_inputedLine.Items.Count; i++)
                {
                    ListViewItem item = listView_inputedLine.Items[i];
                    file.WriteLine(String.Format("E {0} {1} {2} {3}", item.SubItems[0].Text, item.SubItems[1].Text, item.SubItems[2].Text, item.SubItems[3].Text));
                }

                file.Close();
            }
        }

        private void button_Run_Click(object sender, EventArgs e)
        {
            StepMode = false;            
            button_stepBystep.Enabled = false;
            
            sort_point();
            canvas.Clear(Color.White);
            foreach (PointF p in getPoint()) {
                DrawPoint((int)p.X, (int)p.Y);
            }

            ArrayList voronoi = new ArrayList();
            int count_of_data = listView_inputedData.Items.Count;
            if (count_of_data == 0) { MessageBox.Show("請輸入點座標!"); }            
            else if (count_of_data >= 1 && count_of_data <= 3){
                voronoi = LessThan3(getPoint());                
            }else{
                VoronoiEdge[] voronoiArray = RunVoronoi(ArrayListToArray(getPoint()));
                foreach (VoronoiEdge edge in voronoiArray) {
                    voronoi.Add(edge);
                }                          
            }                        
            store_line(voronoi);
            MessageBox.Show("Complete!");
        }

        private void button_continue_Click(object sender, EventArgs e)
        {
            pauseReadFile = false;
            ReadFile();            
            
            endStep = true;
            if (thread != null) { thread.Abort(); thread.Join(); }
            endConvex = true;
            if (thread_convex != null) { thread_convex.Abort(); thread_convex.Join(); }
                        
            button_stepBystep.Enabled = true;
            button_convexhull.Enabled = true;
        }

        private void button_stepBystep_Click(object sender, EventArgs e)
        {
            if (getPoint().Count != 0)
            {
                StepMode = true;
                //上一筆資料已結束
                if (endStep == true)
                {
                    pauseStep = true;
                    thread = new Thread(StepbyStep_Voronoi);
                    thread.IsBackground = true;
                    thread.Start();                    
                    endStep = false;
                }
                else
                {
                    pauseStep = false;
                }
            }
        }

        private void StepbyStep_Voronoi()
        {
            VoronoiEdge[] finalArray = RunVoronoi(ArrayListToArray(getPoint()));
            ArrayList final = new ArrayList();
            foreach (VoronoiEdge edge in finalArray) { final.Add(edge); }
                        
            store_line(final);
            endStep = true;            
            MessageBox.Show("Complete!");
            button_stepBystep.Enabled = false;
        }

        private void StepbyStep_Convex() {
            Run_ConvexHull(ArrayListToArray(getPoint()));
            draw_ConvexHull(getPoint());
            endConvex = true;
            MessageBox.Show("ConvexHull is Complete!");
            button_convexhull.Enabled = false;
        }

        private void button_convexhull_Click(object sender, EventArgs e)
        {
            if (getPoint().Count != 0)
            {                
                //上一筆資料已結束
                if (endConvex == true)
                {
                    pauseConvex = true;
                    thread_convex = new Thread(StepbyStep_Convex);
                    thread_convex.IsBackground = true;
                    thread_convex.Start();                    
                    endConvex = false;
                }
                else
                {
                    pauseConvex = false;
                }
            }
        }

        private void ReadFile()
        {
            //清除畫布和列表中的資料
            canvas.Clear(Color.White);
            listView_inputedData.Items.Clear();
            listView_inputedData.Refresh();
            listView_inputedLine.Items.Clear();
            listView_inputedLine.Refresh();

            System.IO.StreamReader file = new System.IO.StreamReader(open_dialog.FileName);
            string line; //目前正在讀的那行字串內容
            int pointNum = 0; //取得點的個數

            //略過已讀取的部分，從尚未讀取的部分開始讀取
            if (alreadyRead > 1)
            {
                for (int i = 0; i < alreadyRead; i++)
                {
                    line = file.ReadLine();
                }
            }

            while ((line = file.ReadLine()) != null && pauseReadFile == false)
            {
                line = line.Trim();

                if (line == String.Empty || line[0] == '#')
                {
                    alreadyRead += 1 ;
                    continue;
                }
                else if (line[0] == 'P') {

                    ReadOutputFile();
                    break;                
                }
                else
                {
                    pointNum = Int32.Parse(line);
                    if (pointNum == 0)
                    {
                        MessageBox.Show("讀入點數為零，檔案測試停止");
                        button_continue.Enabled = false;
                        button_Run.Enabled = false;
                        button_inputByClick.Enabled = true;
                        button_inputByFile.Enabled = true;
                        alreadyRead = 0;
                        break;
                    }
                    else
                    {
                        alreadyRead += 1;//計算紀錄點個數的那行
                        for (int i = 0; i < pointNum; i++)
                        {
                            line = file.ReadLine();

                            string[] point = line.Split(' ');
                            int x, y;
                            x = Int32.Parse(point[0]);
                            y = Int32.Parse(point[1]);

                            string[] coordinate = { point[0], point[1] };
                            var AddPoint = new ListViewItem(coordinate);
                            listView_inputedData.Items.Add(AddPoint);

                            DrawPoint(x, y);
                            alreadyRead += 1;
                        }

                        button_Run.Enabled = true;
                        button_stepBystep.Enabled = true;
                        button_convexhull.Enabled = true;
                        button_continue.Enabled = true;
                        pauseReadFile = true;
                        button_inputByFile.Enabled = false;                        
                    }
                }                
            }          
        }

        private void ReadOutputFile()
        {
            button_continue.Enabled = false;
            button_inputByClick.Enabled = false;
            button_Run.Enabled = false;
            button_stepBystep.Enabled = false;
            button_convexhull.Enabled = false;

            System.IO.StreamReader file = new System.IO.StreamReader(open_dialog.FileName);
            string line; //目前正在讀的那行字串內容
            
            while ((line = file.ReadLine()) != null)
            {

                line = line.Trim();
                if (line[0] == 'P')
                {
                    string[] point = line.Split(' ');
                    int x, y;
                    x = Int32.Parse(point[1]);
                    y = Int32.Parse(point[2]);
                    DrawPoint(x, y);

                    string[] coordinate = { point[1], point[2] };
                    var AddPoint = new ListViewItem(coordinate);
                    listView_inputedData.Items.Add(AddPoint);
                }
                else
                {
                    string[] point = line.Split(' ');
                    int x1, y1, x2, y2;
                    x1 = Int32.Parse(point[1]);
                    y1 = Int32.Parse(point[2]);
                    x2 = Int32.Parse(point[3]);
                    y2 = Int32.Parse(point[4]);
                    canvas.DrawLine(Yellow_pen, x1, y1, x2, y2);

                    string[] coordinate = { point[1], point[2], point[3], point[4] };
                    var AddLine = new ListViewItem(coordinate);
                    listView_inputedLine.Items.Add(AddLine);
                }
            }
        }

        //將listView_inputedData中的點放入ArrayList
        private ArrayList getPoint()
        {
            sort_point();
            int count_of_data = listView_inputedData.Items.Count;

            ArrayList pointList = new ArrayList();
            for (int i = 0; i < count_of_data; i++)
            {
                PointF point = new PointF();
                ListViewItem item = listView_inputedData.Items[i];
                point.X = Int32.Parse(item.SubItems[0].Text);
                point.Y = Int32.Parse(item.SubItems[1].Text);

                pointList.Add(point);
            }
            return pointList;
        }

        //將PointF[]轉成ArrayList
        private ArrayList PointFtoArrayList(PointF[] array)
        {
            ArrayList arraylist = new ArrayList();
            foreach (PointF p in array)
            {
                arraylist.Add(p);
            }
            return arraylist;
        }

        private PointF[] ArrayListToArray(ArrayList arrayList) { 
            int count = arrayList.Count;
            PointF[] array = new PointF[count];
            array = (PointF[])arrayList.ToArray(typeof(PointF));
            return array;
        }

        private void sort_point()
        {
            int count_of_data = listView_inputedData.Items.Count;
            int[] arrayX = new int[count_of_data];
            int[] arrayY = new int[count_of_data];

            //將listView_inputedData中的資料放入array
            for (int i = 0; i < count_of_data; i++)
            {
                ListViewItem item = listView_inputedData.Items[i];
                int x = Int32.Parse(item.SubItems[0].Text);
                int y = Int32.Parse(item.SubItems[1].Text);

                arrayX[i] = x;
                arrayY[i] = y;
            }

            //將array中的資料進行排序
            int tmp;
            for (int i = 0; i < count_of_data - 1; i++)
            {
                for (int j = i + 1; j < count_of_data; j++)
                {
                    if (arrayX[i] > arrayX[j])
                    {
                        tmp = arrayX[i]; arrayX[i] = arrayX[j]; arrayX[j] = tmp;
                        tmp = arrayY[i]; arrayY[i] = arrayY[j]; arrayY[j] = tmp;
                    }
                    else if (arrayX[i] == arrayX[j])
                    {
                        if (arrayY[i] > arrayY[j])
                        {
                            tmp = arrayX[i]; arrayX[i] = arrayX[j]; arrayX[j] = tmp;
                            tmp = arrayY[i]; arrayY[i] = arrayY[j]; arrayY[j] = tmp;
                        }
                    }
                }
            }

            //將排序好的資料放回listView_inputedData中
            listView_inputedData.Items.Clear();
            listView_inputedData.Refresh();
            for (int i = 0; i < count_of_data; i++)
            {
                int x = arrayX[i];
                int y = arrayY[i];
                string[] coordinate = { x.ToString(), y.ToString() };
                var AddPoint = new ListViewItem(coordinate);
                listView_inputedData.Items.Add(AddPoint);
            }
        }

        private void sort_line()
        {
            int count_of_data = listView_inputedLine.Items.Count;
            int[] arrayX1 = new int[count_of_data];
            int[] arrayY1 = new int[count_of_data];
            int[] arrayX2 = new int[count_of_data];
            int[] arrayY2 = new int[count_of_data];

            //將listView_inputedLine中的資料放入array
            for (int i = 0; i < count_of_data; i++)
            {
                ListViewItem item = listView_inputedLine.Items[i];
                int x1 = Int32.Parse(item.SubItems[0].Text);
                int y1 = Int32.Parse(item.SubItems[1].Text);
                int x2 = Int32.Parse(item.SubItems[2].Text);
                int y2 = Int32.Parse(item.SubItems[3].Text);

                arrayX1[i] = x1;
                arrayY1[i] = y1;
                arrayX2[i] = x2;
                arrayY2[i] = y2;
            }

            //將array中的資料進行排序
            int tmp;

            //將每條線段的x1、x2進行比較，令較小者為x1
            for (int i = 0; i < count_of_data; i++)
            {
                if (arrayX1[i] > arrayX2[i])
                {
                    tmp = arrayX1[i]; arrayX1[i] = arrayX2[i]; arrayX2[i] = tmp;
                    tmp = arrayY1[i]; arrayY1[i] = arrayY2[i]; arrayY2[i] = tmp;
                }
                //若x1=x2，則比較y座標
                else if (arrayX1[i] == arrayX2[i])
                {
                    if (arrayY1[i] > arrayY2[i])
                    {
                        tmp = arrayX1[i]; arrayX1[i] = arrayX2[i]; arrayX2[i] = tmp;
                        tmp = arrayY1[i]; arrayY1[i] = arrayY2[i]; arrayY2[i] = tmp;
                    }
                }
            }

            //將所有線段依照X1的大小進行排序
            for (int i = 0; i < count_of_data - 1; i++)
            {
                for (int j = i + 1; j < count_of_data; j++)
                {
                    if (arrayX1[i] > arrayX1[j])
                    {
                        tmp = arrayX1[i]; arrayX1[i] = arrayX1[j]; arrayX1[j] = tmp;
                        tmp = arrayY1[i]; arrayY1[i] = arrayY1[j]; arrayY1[j] = tmp;
                        tmp = arrayX2[i]; arrayX2[i] = arrayX2[j]; arrayX2[j] = tmp;
                        tmp = arrayY2[i]; arrayY2[i] = arrayY2[j]; arrayY2[j] = tmp;
                    }
                    //若X1相同則比較Y1
                    else if (arrayX1[i] == arrayX1[j])
                    {
                        if (arrayY1[i] > arrayY1[j])
                        {
                            tmp = arrayX1[i]; arrayX1[i] = arrayX1[j]; arrayX1[j] = tmp;
                            tmp = arrayY1[i]; arrayY1[i] = arrayY1[j]; arrayY1[j] = tmp;
                            tmp = arrayX2[i]; arrayX2[i] = arrayX2[j]; arrayX2[j] = tmp;
                            tmp = arrayY2[i]; arrayY2[i] = arrayY2[j]; arrayY2[j] = tmp;
                        }
                        //若Y1相同則比較X2
                        else if (arrayY1[i] == arrayY1[j])
                        {
                            if (arrayX2[i] > arrayX2[j])
                            {
                                tmp = arrayX1[i]; arrayX1[i] = arrayX1[j]; arrayX1[j] = tmp;
                                tmp = arrayY1[i]; arrayY1[i] = arrayY1[j]; arrayY1[j] = tmp;
                                tmp = arrayX2[i]; arrayX2[i] = arrayX2[j]; arrayX2[j] = tmp;
                                tmp = arrayY2[i]; arrayY2[i] = arrayY2[j]; arrayY2[j] = tmp;
                            }
                            //若X2相同則比較Y2
                            else if (arrayX2[i] == arrayX2[j])
                            {
                                if (arrayY2[i] > arrayY2[j])
                                {
                                    tmp = arrayX1[i]; arrayX1[i] = arrayX1[j]; arrayX1[j] = tmp;
                                    tmp = arrayY1[i]; arrayY1[i] = arrayY1[j]; arrayY1[j] = tmp;
                                    tmp = arrayX2[i]; arrayX2[i] = arrayX2[j]; arrayX2[j] = tmp;
                                    tmp = arrayY2[i]; arrayY2[i] = arrayY2[j]; arrayY2[j] = tmp;
                                }
                            }
                        }
                    }
                }
            }

            //將排序好的資料放回listView_inputedLine中
            listView_inputedLine.Items.Clear();
            listView_inputedLine.Refresh();
            for (int i = 0; i < count_of_data; i++)
            {
                int x1 = arrayX1[i];
                int y1 = arrayY1[i];
                int x2 = arrayX2[i];
                int y2 = arrayY2[i];

                string[] coordinate = { x1.ToString(), y1.ToString(), x2.ToString(), y2.ToString() };
                var AddLine = new ListViewItem(coordinate);
                listView_inputedLine.Items.Add(AddLine);
            }
        }

        //檢查是否有共線
        private bool SameLine(PointF p1, PointF p2, PointF p3)
        {

            //計算斜率
            float m1 = (p2.Y - p1.Y) / (p2.X - p1.X);
            float m2 = (p3.Y - p1.Y) / (p3.X - p1.X);
            float m3 = (p3.Y - p2.Y) / (p3.X - p2.X);

            if (((p1.X == p2.X) && (p2.X == p3.X)) || ((p1.Y == p2.Y) && (p2.Y == p3.Y)))
            {
                return true;
            }
            else if ((m1 == m2) && (m2 == m3))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //檢查是否有共點
        private int overlap(PointF x, PointF y, PointF z)
        {
            //處裡三點重疊的情況
            if (((x.X == y.X) && (y.X == z.X)) && ((x.Y == y.Y) && (y.Y == z.Y))) { return 1; }
            //處裡其中兩點重疊的情況
            else if ((x.X == y.X) && (x.Y == y.Y)) { return 2; }
            else if ((x.X == z.X) && (x.Y == z.Y)) { return 3; }
            else if ((y.X == z.X) && (y.Y == z.Y)) { return 4; }
            else { return 0; }
        }

        private float square(float n) { return (float)Math.Pow(n, 2); }

        //輸入三點，找出三條中垂線之交點(外心)
        private PointF circumcenter(PointF p1,PointF p2,PointF p3)
        {
            float x1 = p1.X; float y1 = p1.Y;
            float x2 = p2.X; float y2 = p2.Y;
            float x3 = p3.X; float y3 = p3.Y;

            //外心座標(float型態)
            PointF cir = new PointF();

            //根據「外心到三頂點距離相等」的特性，化簡可得以下
            float A1, B1, C1, A2, B2, C2;
            A1 = 2 * (x2 - x1);
            B1 = 2 * (y2 - y1);
            C1 = square(x2) + square(y2) - square(x1) - square(y1);
            A2 = 2 * (x3 - x2);
            B2 = 2 * (y3 - y2);
            C2 = square(x3) + square(y3) - square(x2) - square(y2);

            cir.X = ((C1 * B2) - (C2 * B1)) / ((A1 * B2) - (A2 * B1));
            cir.Y = ((A1 * C2) - (A2 * C1)) / ((A1 * B2) - (A2 * B1));

            return cir;
        }

        //計算角ABC的角度
        private float Angle(PointF p1, PointF p2, PointF p3)
        {
            float uX = p1.X - p2.X; //向量BA的X項
            float uY = p1.Y - p2.Y; //向量BA的Y項
            float vX = p3.X - p2.X; //向量BC的X項
            float vY = p3.Y - p2.Y; //向量BC的Y項

            //cos角ABC = (BA向量內積BC向量)/((BA向量的長度)*(BC向量的長度)) 
            //計算結果單位為弧度，須再乘上180並除以PI才會轉成角度

            return (float)(Math.Acos((uX * vX + uY * vY) / (Math.Sqrt(uX * uX + uY * uY) * Math.Sqrt(vX * vX + vY * vY))) * 180 / Math.PI);
        }

        //輸入兩點，計算中垂線
        private VoronoiEdge compute(PointF x, PointF y)
        {
            PointF mid = new PointF((x.X + y.X) / 2, (x.Y + y.Y) / 2);            
            float mX = -(x.Y - y.Y) / 2;
            float mY = (x.X - y.X) / 2;
            PointF start = new PointF(mid.X, mid.Y);
            PointF end = new PointF(mid.X, mid.Y);

            while (true) {
                if (start.X >= -700000 && start.X <= 700700 && start.Y >= -700000 && start.Y <= 700700)
                {
                    start.X -= mX;
                    start.Y -= mY;
                }
                else if (end.X >= -700000 && end.X <= 700700 && end.Y >= -700000 && end.Y <= 700700)
                {
                    end.X += mX;
                    end.Y += mY;
                }
                else {
                    break;
                }
            }  
            return new VoronoiEdge(start, end, x, y);
        }

        //計算三角形的Voronoi
        private ArrayList remove_surplusLine(PointF p1, PointF p2, PointF p3)
        {
            ArrayList edgeList = new ArrayList();
            VoronoiEdge edge = new VoronoiEdge();

            PointF midpoint1 = new PointF();
            PointF midpoint2 = new PointF();
            PointF midpoint3 = new PointF();

            //計算中點
            midpoint1.X = (p1.X + p2.X) / 2; midpoint1.Y = (p1.Y + p2.Y) / 2;
            midpoint2.X = (p1.X + p3.X) / 2; midpoint2.Y = (p1.Y + p3.Y) / 2;
            midpoint3.X = (p2.X + p3.X) / 2; midpoint3.Y = (p2.Y + p3.Y) / 2;

            //計算角度
            float angle1 = Angle(p1, p3, p2);
            float angle2 = Angle(p1, p2, p3);
            float angle3 = Angle(p2, p1, p3);

            PointF cir = circumcenter(p1, p2, p3);

            //計算中垂線兩端點的座標
            VoronoiEdge result = compute(p1, p2);

            //若為銳角三角形//
            if ((angle1 < 90) && (angle2 < 90) && (angle3 < 90))
            {
                edge = Acute(p1, p2, cir, midpoint1); edgeList.Add(edge);
                edge = Acute(p1, p3, cir, midpoint2); edgeList.Add(edge);
                edge = Acute(p2, p3, cir, midpoint3); edgeList.Add(edge);
            }

            //若為直角三角形//
            else if ((angle1 == 90) || (angle2 == 90) || (angle3 == 90))
            {
                string[] coordinate = new string[] { };

                //若angle1為直角，則angle2、angle3為銳角
                if (angle1 == 90)
                {
                    result = compute(p1, p2);

                    if (((result.endPoint.X - cir.X) * (cir.X - p3.X) + (result.endPoint.Y - cir.Y) * (cir.Y - p3.Y)) >= 0)
                    {
                        edge.startPoint = cir;
                        edge.endPoint = result.endPoint;
                    }
                    else if (((result.startPoint.X - cir.X) * (cir.X - p3.X) + (result.startPoint.Y - cir.Y) * (cir.Y - p3.Y)) >= 0)
                    {
                        edge.startPoint = result.startPoint;
                        edge.endPoint = cir;
                    }

                    edgeList.Add(edge);
                    edge = Acute(p1, p3, cir, midpoint2); edgeList.Add(edge);
                    edge = Acute(p2, p3, cir, midpoint3); edgeList.Add(edge);
                }

                //若angle2為直角，則angle1、angle3為銳角
                else if (angle2 == 90)
                {
                    result = compute(p1, p3);
                    if (((result.endPoint.X - cir.X) * (cir.X - p2.X) + (result.endPoint.Y - cir.Y) * (cir.Y - p2.Y)) >= 0)
                    {
                        edge.startPoint = result.endPoint;
                        edge.endPoint = cir;
                    }
                    else if (((result.startPoint.X - cir.X) * (cir.X - p2.X) + (result.startPoint.Y - cir.Y) * (cir.Y - p2.Y)) >= 0)
                    {
                        edge.startPoint = result.startPoint;
                        edge.endPoint = cir;
                    }

                    edgeList.Add(edge);
                    edge = Acute(p1, p2, cir, midpoint1); edgeList.Add(edge);
                    edge = Acute(p2, p3, cir, midpoint3); edgeList.Add(edge);
                }

                //若angle3為直角，則angle1、angle2為銳角
                else if (angle3 == 90)
                {
                    result = compute(p2, p3);

                    if (((result.endPoint.X - cir.X) * (cir.X - p1.X) + (result.endPoint.Y - cir.Y) * (cir.Y - p1.Y)) >= 0)
                    {
                        edge.startPoint = result.endPoint;
                        edge.endPoint = cir;
                    }
                    else if (((result.startPoint.X - cir.X) * (cir.X - p1.X) + (result.startPoint.Y - cir.Y) * (cir.Y - p1.Y)) >= 0)
                    {
                        edge.startPoint = result.startPoint;
                        edge.endPoint = cir;
                    }

                    edgeList.Add(edge);
                    edge = Acute(p1, p2, cir, midpoint1); edgeList.Add(edge);
                    edge = Acute(p1, p3, cir, midpoint2); edgeList.Add(edge);
                }
            }

            //若為鈍角三角形//
            else if ((angle1 > 90) || (angle2 > 90) || (angle3 > 90))
            {
                //若angle1為鈍角，則angle2、angle3為銳角
                if (angle1 > 90)
                {
                    edge = Obtuse(p1, p2, cir, midpoint1); edgeList.Add(edge);
                    edge = Acute(p1, p3, cir, midpoint2); edgeList.Add(edge);
                    edge = Acute(p2, p3, cir, midpoint3); edgeList.Add(edge);
                }
                //若angle2為鈍角，則angle1、angle3為銳角
                else if (angle2 > 90)
                {
                    edge = Obtuse(p1, p3, cir, midpoint2); edgeList.Add(edge);
                    edge = Acute(p1, p2, cir, midpoint1); edgeList.Add(edge);
                    edge = Acute(p2, p3, cir, midpoint3); edgeList.Add(edge);
                }
                //若angle3為鈍角，則angle1、angle2為銳角
                else if (angle3 > 90)
                {
                    edge = Obtuse(p2, p3, cir, midpoint3); edgeList.Add(edge);
                    edge = Acute(p1, p2, cir, midpoint1); edgeList.Add(edge);
                    edge = Acute(p1, p3, cir, midpoint2); edgeList.Add(edge);
                }
            }
            return edgeList;
        }

        //若線段p1p2對應的角度為鈍角
        private VoronoiEdge Obtuse(PointF p1, PointF p2, PointF cir, PointF midpoint)
        {

            VoronoiEdge result = compute(p1, p2);
            PointF endpoint = new PointF();

            //判斷中點與中垂線是否在同一個線段上
            //若兩向量內積=0，代表兩向量同向
            if (((result.endPoint.X - cir.X) * (cir.X - midpoint.X) + (result.endPoint.Y - cir.Y) * (cir.Y - midpoint.Y)) >= 0)
            {
                endpoint.X = result.endPoint.X;
                endpoint.Y = result.endPoint.Y;
            }
            else if (((result.startPoint.X - cir.X) * (cir.X - midpoint.X) + (result.startPoint.Y - cir.Y) * (cir.Y - midpoint.Y)) >= 0)
            {
                endpoint.X = result.startPoint.X;
                endpoint.Y = result.startPoint.Y;
            }
            return new VoronoiEdge(cir, endpoint, p1, p2);
        }

        //若線段p1p2對應的角度為銳角
        private VoronoiEdge Acute(PointF p1, PointF p2, PointF cir, PointF midpoint)
        {

            VoronoiEdge result = compute(p1, p2);
            PointF endpoint = new PointF();

            //判斷中點與中垂線是否在同一個線段上
            //若兩向量內積=0，代表兩向量同向
            if (((result.endPoint.X - midpoint.X) * (midpoint.X - cir.X) + (result.endPoint.Y - midpoint.Y) * (midpoint.Y - cir.Y)) >= 0)
            {
                endpoint.X = result.endPoint.X;
                endpoint.Y = result.endPoint.Y;
            }
            else if (((result.startPoint.X - midpoint.X) * (midpoint.X - cir.X) + (result.startPoint.Y - midpoint.Y) * (midpoint.Y - cir.Y)) >= 0)
            {
                endpoint.X = result.startPoint.X;
                endpoint.Y = result.startPoint.Y;
            }
            return new VoronoiEdge(cir, endpoint, p1, p2);
        }

        //處理三點以下的Voronoi Diagram
        private ArrayList LessThan3(ArrayList pointList)
        {

            int count_of_data = pointList.Count;
            ArrayList CollectionOfEdge = new ArrayList();
            VoronoiEdge edge;

            if (count_of_data == 1) { MessageBox.Show("單點無法繪出圖形"); }
            else
            {
                PointF p1, p2, p3;
                if (count_of_data == 2)
                {
                    p1 = (PointF)pointList[0];
                    p2 = (PointF)pointList[1];

                    if ((p1.X == p2.X) && (p1.Y == p2.Y))
                    {
                        MessageBox.Show("兩點重疊無法繪出圖形");
                    }
                    else
                    {
                        edge = compute(p1, p2); CollectionOfEdge.Add(edge);
                    }
                }

                if (count_of_data == 3)
                {
                    p1 = (PointF)pointList[0];//讀取第一點                    
                    p2 = (PointF)pointList[1];//讀取第二點
                    p3 = (PointF)pointList[2];//讀取第三點

                    //若三點不共線
                    if (SameLine(p1, p2, p3) == false)
                    {
                        //檢查是否有重疊的點
                        if (overlap(p1, p2, p3) == 0)
                        {
                            //檢查這三個點是否能形成三角形(兩邊和是否大於第三邊)
                            float a, b, c;
                            a = (float)Math.Sqrt(square(p1.X - p2.X) + square(p1.Y - p2.Y));
                            b = (float)Math.Sqrt(square(p1.X - p3.X) + square(p1.Y - p3.Y));
                            c = (float)Math.Sqrt(square(p2.X - p3.X) + square(p2.Y - p3.Y));

                            if (a >= b + c || b >= a + c || c >= a + b)
                            {
                                MessageBox.Show("這三點無法形成三角形");
                                edge = compute(p1, p2); CollectionOfEdge.Add(edge);
                                edge = compute(p2, p3); CollectionOfEdge.Add(edge);
                            }
                            else
                            {
                                //處理外心在畫布範圍之外的情況
                                PointF cir = circumcenter(p1, p2, p3);

                                ArrayList edgeList = new ArrayList();
                                edgeList = remove_surplusLine(p1, p2, p3);
                                foreach (VoronoiEdge line in edgeList)
                                {
                                    CollectionOfEdge.Add(line);
                                }
                            }
                        }
                    }

                    //若三點共線
                    else
                    {
                        //若有重複的點
                        if (overlap(p1, p2, p3) > 0)
                        {
                            int tmp = overlap(p1, p2, p3);
                            if (tmp == 1) { MessageBox.Show("三點重疊"); }
                            else if (tmp == 2)
                            {
                                MessageBox.Show("兩點重疊");
                                edge = compute(p2, p3); CollectionOfEdge.Add(edge);
                            }
                            else if (tmp == 3)
                            {
                                MessageBox.Show("兩點重疊");
                                edge = compute(p1, p2); CollectionOfEdge.Add(edge);
                            }
                            else if (tmp == 4)
                            {
                                MessageBox.Show("兩點重疊");
                                edge = compute(p1, p2); CollectionOfEdge.Add(edge);
                            }
                        }

                        if (overlap(p1, p2, p3) == 0)
                        {
                            MessageBox.Show("三點共線");
                            edge = compute(p1, p2);
                            CollectionOfEdge.Add(edge);
                            edge = compute(p2, p3);
                            CollectionOfEdge.Add(edge);
                        }
                    }
                }
            }
            return CollectionOfEdge;
        }

        //向量p1p2外積向量p1p3，若外積結果小於0，代表p1p2到p1p3為逆時針旋轉(p3在p1p2的左邊)
        //向量p1p2外積向量p1p3，若外積結果大於0，代表p1p2到p1p3為順時針旋轉(p3在p1p2的右邊)
        private float crossproduct(PointF p1, PointF p2, PointF p3)
        {
            return ((p2.X - p1.X) * (p3.Y - p1.Y) - (p2.Y - p1.Y) * (p3.X - p1.X));
        }
        
        //求兩點間的距離(尚未開根號)
        private float distance(PointF p1,PointF p2) {
            return (p1.X - p2.X) * (p1.X - p2.X) + (p1.Y - p2.Y) * (p1.Y - p2.Y);
        }
                
        //若p1p2的距離大於p1p3的距離，回傳true
        //若p1p2的距離小於p1p3的距離，回傳false
        private bool compare_distance(PointF p1, PointF p2, PointF p3) {

            if (distance(p1,p2) > distance(p1,p3)) { return true; }
            else { return false; }
        }

        //找出convex中的點
        private ArrayList ConvexHull(PointF[] pointList)
        {
            ArrayList convex = new ArrayList();

            //若點的個數少於三點，直接全部放入convex
            if (pointList.Length <= 2) {
                foreach (PointF point in pointList) { convex.Add(point); }
            }
            else {
                //Jarvis_March演算法

                //找出起始點(起始點必須是ConvexHull上的點，頂點那幾點的其中一點)，這裡找最左下角的點
                int startpoint_index = 0;//紀錄起始點的index
                for (int i = 0; i < pointList.Length; i++) {
                    //找出最左下角的點                    
                    if((pointList[i].Y < pointList[startpoint_index].Y) || ((pointList[i].Y == pointList[startpoint_index].Y) && (pointList[i].X < pointList[startpoint_index].X))){
                        startpoint_index = i;
                    }
                }

                //把起始點加入convex
                convex.Add(pointList[startpoint_index]);
                
                //紀錄已經找到的convex點個數
                int point_num = 1;
                while (true) {

                    //順時針方向找出位於最外圍的點，若有多點共線的情形，則找最遠的點。
                    int nextpoint_index = startpoint_index; //令第一個檢查基準點為起始點
                    for (int i = 0; i < pointList.Length; i++)
                    {
                        PointF lastpoint = (PointF)convex[point_num - 1];//目前convex中最後一個點(也就是上一個放入convex的點)
                        PointF checkpoint = pointList[i];//要檢查的點
                        PointF nextpoint = pointList[nextpoint_index];//檢查的基準點

                        //以lastpoint為中心，計算外積
                        float cross = crossproduct(lastpoint, checkpoint, nextpoint);

                        //若外積結果大於0，代表在順時針方向，checkpoint是比nextpoint還靠外的點
                        //以checkpoint取代nextpoint作為檢查的基準點
                        if (cross > 0) { nextpoint_index = i; }

                        //若外積結果等於0，代表兩點共線(向量平行)，找距離較遠的點
                        //若checkpoint至lastpoint的距離比nextpoint至lastpoint的距離還遠
                        //以checkpoint取代nextpoint作為檢查的基準點
                        else if (cross == 0) {

                            //若lastpoint == nextpoint
                            if (compare_distance(lastpoint, checkpoint, nextpoint) == true && distance(lastpoint, nextpoint) == 0) {
                                nextpoint_index = i;
                            }
                            //若lastpoint == checkpoint
                            else if(compare_distance(lastpoint,checkpoint,nextpoint) == false && !convex.Contains(checkpoint)){
                                nextpoint_index = i;
                            }
                        }
                    }

                    //若已經檢查完一輪，則跳出迴圈，把找到的點加入convex
                    if (nextpoint_index == startpoint_index) { break; }
                    convex.Add(pointList[nextpoint_index]);
                    point_num += 1;                    
                }
            }
            return convex;
        }

        //畫出指定陣列的ConvexHull
        private void draw_ConvexHull(ArrayList pointList)
        {
            ArrayList convexPoint = ConvexHull(ArrayListToArray(pointList));
            for (int i = 0; i < convexPoint.Count - 1; i++)
            {
                canvas.DrawLine(Gainsboro_pen, (PointF)convexPoint[i], (PointF)convexPoint[i + 1]);
            }
            canvas.DrawLine(Gainsboro_pen, (PointF)convexPoint[0], (PointF)convexPoint[convexPoint.Count - 1]);
        }    
        
        private void Run_ConvexHull(PointF[] Point)
        {            
            if (Point.Length <= 3) { draw_ConvexHull(PointFtoArrayList(Point)); }
            else {

                //把點divide成兩半
                PointF[] PointLeft = new PointF[Point.Length / 2];
                PointF[] PointRight = new PointF[Point.Length - (Point.Length / 2)];

                //將原本的point資料複製到左右集合中                
                for (int i = 0; i < Point.Length / 2; i++){
                    PointLeft[i] = Point[i];
                }
                int index = 0;
                for (int i = Point.Length / 2; i < Point.Length; i++){
                    PointRight[index] = Point[i]; index += 1;
                }

                Run_ConvexHull(PointLeft); 
                Run_ConvexHull(PointRight);

                foreach (PointF p in PointLeft) { canvas.DrawEllipse(LightSkyBlue_pen, p.X, p.Y, 5, 5); }
                foreach (PointF p in PointRight) { canvas.DrawEllipse(LightSalmon_pen, p.X, p.Y, 5, 5); }

                draw_ConvexHull(ConvexHull(PointLeft));
                draw_ConvexHull(ConvexHull(PointRight));
                pause_Convex();
                draw_ConvexHull(ConvexHull(Point));  

                canvas.Clear(Color.White);
                foreach (PointF p in getPoint()) {
                    canvas.DrawEllipse(Black_pen, p.X, p.Y,5,5);
                }
                draw_ConvexHull(ConvexHull(Point));                
            }
        }

        private VoronoiEdge[] RunVoronoi(PointF[] Point)
        {            
            ArrayList final = new ArrayList();
            
            if (Point.Length <= 3)
            {
                final = LessThan3(PointFtoArrayList(Point));
            }
            else {
                
                //把點divide成兩半
                PointF[] PointLeft = new PointF[Point.Length / 2];
                PointF[] PointRight = new PointF[Point.Length - (Point.Length / 2)];

                //將原本的point資料複製到左右集合中                
                for (int i = 0; i < Point.Length / 2; i++) {
                    PointLeft[i] = Point[i];
                }
                int index = 0;
                for (int i = Point.Length / 2; i < Point.Length; i++) {
                    PointRight[index] = Point[i]; index += 1;
                }
                                              
                VoronoiEdge[] left = RunVoronoi(PointLeft);
                VoronoiEdge[] right = RunVoronoi(PointRight);

                if (StepMode)
                {
                    foreach (PointF p in PointLeft) { canvas.DrawEllipse(LightSkyBlue_pen, p.X, p.Y, 5, 5); }
                    foreach (PointF p in PointRight) { canvas.DrawEllipse(LightSalmon_pen, p.X, p.Y, 5, 5); }
                }
                
                ArrayList EdgeLeft = new ArrayList();
                ArrayList EdgeRight = new ArrayList();

                foreach (VoronoiEdge edge in left) {
                    EdgeLeft.Add(edge);
                    if (StepMode) { canvas.DrawLine(LightSkyBlue_pen, edge.startPoint, edge.endPoint); }
                }                
                foreach (VoronoiEdge edge in right)
                {
                    EdgeRight.Add(edge);
                    if (StepMode) { canvas.DrawLine(LightSalmon_pen, edge.startPoint, edge.endPoint); }
                }                

                final = MergeVoronoi(Point, PointLeft, PointRight, EdgeLeft, EdgeRight);

                //整理畫面
                canvas.Clear(Color.White);
                foreach (PointF p in Point) { canvas.DrawEllipse(Black_pen, p.X, p.Y, 5, 5); }
                if (StepMode) { foreach (VoronoiEdge e in final) { canvas.DrawLine(Gainsboro_pen, e.startPoint, e.endPoint); }}
            }
            return (VoronoiEdge[])final.ToArray(typeof(VoronoiEdge));
        }

        private ArrayList MergeVoronoi(PointF[] point, PointF[] pointLeft,PointF[] pointRight,ArrayList edgeLeft,ArrayList edgeRight) {

            //最後回傳的結果
            ArrayList final = new ArrayList();            
            ArrayList hyperLine = new ArrayList();
                       
            //ConvexHull的點集合
            ArrayList convexhullLeft = ConvexHull(pointLeft);
            ArrayList convexhullRight = ConvexHull(pointRight);
            ArrayList convexhullMerge = ConvexHull(point);
            PointF[] convexhullLeftToArray = ArrayListToArray(convexhullLeft);
            PointF[] convexhullRightToArray = ArrayListToArray(convexhullRight);
            PointF[] convexhullMergeToArray = ArrayListToArray(convexhullMerge);

            //公切點
            PointF[] common = getCommonPoint(convexhullLeftToArray, convexhullRightToArray, convexhullMergeToArray);
            PointF LT = common[0]; //左半邊的ConvexHull中最上面的點
            PointF RT = common[1]; //右半邊的ConvexHull中最上面的點
            PointF LB = common[3]; //左半邊的ConvexHull中最下面的點
            PointF RB = common[2]; //右半邊的ConvexHull中最下面的點
            PointF cp1 = LT, cp2 = RT; //從cp1 = LT、cp2 = RT開始，至cp1 = LB、cp2 = RB結束    
            
            //初始化
            PointF crosspoint = new PointF();//Hyperline和左右voronoi的交點
            PointF precrosspoint = new PointF(0, float.NegativeInfinity);//上一個Hyperline和左右voronoi的交點
            bool firststep = true;//是否第一條hyperline
            bool findcross = true;//是否有找到交點
            bool side = false; //false代表左邊，true代表右邊

            VoronoiEdge midLine = new VoronoiEdge();
            VoronoiEdge midLine_original = new VoronoiEdge();
            VoronoiEdge crossLine = new VoronoiEdge();
            VoronoiEdge precrossLine = new VoronoiEdge();

            //畫上目前狀態下的ConvexHull
            if (StepMode) { draw_ConvexHull(ConvexHull(point)); }

            //處理Hyperline(順時針方向檢查公切點)-----------------------------------------------------------
            while (findcross == true) {

                //兩個檢查點的中垂線(一條保留原本的樣子、一條用於修改)
                midLine = compute(cp1, cp2);
                midLine_original = compute(cp1, cp2);
                
                findcross = false;
                crosspoint = new PointF(float.PositiveInfinity, float.PositiveInfinity);
                crossLine = new VoronoiEdge();                

                //找出左邊Voronoi與midLine的交點                
                foreach (VoronoiEdge edge in edgeLeft)
                {
                    PointF cross = new PointF();
                    PointF parent = new PointF();

                    //若cp1是產生這條中垂線edge的兩個點之中較高的那個點
                    if (parentofedge(edge, cp1) == 'H')
                    {
                        parent = edge.parentLow;
                        if (crossproduct(cp1, cp2, parent) == 0) { continue; }//向量外積=0代表平行，跳過此步驟
                        else { cross = circumcenter(cp1, cp2, parent); }
                    }
                    //若cp1是產生這條中垂線edge的兩個點之中較低的那個點
                    else if (parentofedge(edge, cp1) == 'L')
                    {
                        parent = edge.parentHigh;
                        if (crossproduct(cp1, cp2, parent) == 0) { continue; }//向量外積=0代表平行，跳過此步驟
                        else { cross = circumcenter(cp1, cp2, parent); }
                    }
                    //若cp1不是產生這條中垂線edge的兩個點之一
                    else
                    {
                        if (crossproduct(cp1, cp2, edge.parentHigh) == 0) { continue; }
                        cross = Intersection(edge, midLine);
                    }
                    //若交點p在這條中垂線edge線段上而且Y座標比上一個交點大(在上一個交點下方)
                    if (OnEdge(edge, cross) && cross.Y >= precrosspoint.Y && !edge.Equals(precrossLine))
                    {
                        if (cross.Y < crosspoint.Y || (cross.Y == crosspoint.Y && cross.X > crosspoint.X))
                        {
                            crosspoint = cross;
                            crossLine = edge;
                            findcross = true;
                            side = false;
                        }
                    }
                }             
                
                if (!findcross) { crosspoint = new PointF(float.NegativeInfinity, float.PositiveInfinity); }               
                                
                //找出右邊Voronoi與midLine的交點
                foreach (VoronoiEdge edge in edgeRight)
                {                    
                    PointF cross = new PointF();
                    PointF parent = new PointF();

                    //若cp2是產生這條中垂線edge的兩個點之中較高的那個點
                    if (parentofedge(edge, cp2) == 'H') {
                        parent = edge.parentLow;                        
                        if (crossproduct(cp1, cp2, parent) == 0) { continue; }//向量外積=0代表平行，跳過此步驟
                        else { cross = circumcenter(cp1, cp2, parent); }                       
                    }
                    //若cp2是產生這條中垂線edge的兩個點之中較低的那個點
                    else if (parentofedge(edge, cp2) == 'L') {
                        parent = edge.parentHigh;                        
                        if (crossproduct(cp1, cp2, parent) == 0) { continue; }//向量外積=0代表平行，跳過此步驟
                        else { cross = circumcenter(cp1, cp2, parent); }                        
                    }
                    //若cp2不是產生這條中垂線edge的兩個點之一
                    else {                        
                        if (crossproduct(cp1, cp2, edge.parentHigh) == 0) { continue; }
                        cross = Intersection(edge, midLine);
                    }
                    //若交點p在這條中垂線edge線段上而且Y座標比上一個交點大(在上一個交點下方)
                    if (OnEdge(edge, cross) && cross.Y >= precrosspoint.Y && !edge.Equals(precrossLine))
                    {
                        if (cross.Y < crosspoint.Y || (cross.Y == crosspoint.Y && cross.X < crosspoint.X))
                        {
                            crosspoint = cross;
                            crossLine = edge;
                            findcross = true;
                            side = true;
                        }
                    }                    
                }
                
                if (crosspoint.X > 700700 || crosspoint.X < -700000 || crosspoint.Y > 700700 || crosspoint.Y < -700000)
                {
                    findcross = false;                    
                    break;
                }                
                
                //修改midLine-------------------------------------------------------------------------------
                
                //若不是在畫第一條HyperLine，則線段起點為上一個交點
                //Y座標較大的那個端點以crosspoint取代
                //若Y座標相等，若是和右邊voronoi相交則取較右邊的點(endpoint)，若是和左邊voronoi相交則取較左邊的點(startpoint)
                if ((midLine.startPoint.Y < midLine.endPoint.Y) || (midLine.startPoint.Y == midLine.endPoint.Y && side == true))
                {
                    if (!firststep) {midLine.startPoint = precrosspoint;}
                    midLine.endPoint = crosspoint;
                }
                else if ((midLine.startPoint.Y > midLine.endPoint.Y) || (midLine.startPoint.Y == midLine.endPoint.Y && side == false))
                {
                    if (!firststep) {midLine.endPoint = precrosspoint;}
                    midLine.startPoint = crosspoint;
                }
                
                midLine = Intersort_byX(midLine);
                final.Add(midLine);                
                hyperLine.Add(midLine);

                //修改左右的voronoi在與midLine相交後的端點--------------------------------------------------
                                
                if (side == false)
                {                    
                    Tuple<ArrayList, VoronoiEdge, PointF> tupleL = modify_endpoint(edgeLeft, cp1, false, crossLine, crosspoint, midLine_original);
                    edgeLeft = new ArrayList(tupleL.Item1);
                    crossLine.startPoint = tupleL.Item2.startPoint;
                    crossLine.endPoint = tupleL.Item2.endPoint;
                    cp1 = tupleL.Item3;                    
                }
                else
                {                    
                    Tuple<ArrayList, VoronoiEdge, PointF> tupleR = modify_endpoint(edgeRight, cp2, true, crossLine, crosspoint, midLine_original);
                    edgeRight = new ArrayList(tupleR.Item1);
                    crossLine.startPoint = tupleR.Item2.startPoint;
                    crossLine.endPoint = tupleR.Item2.endPoint;
                    cp2 = tupleR.Item3;
                }

                //將修改好的左右VoronoiEdge也存入final
                foreach (VoronoiEdge e in edgeLeft) { final.Add(e); }
                foreach (VoronoiEdge e in edgeRight) { final.Add(e); }
                
                precrosspoint = crosspoint;
                precrossLine = crossLine;
                firststep = false;
                if (cp1 == LB && cp2 == RB) { break; }
            }

            //處理最後一條HyperLine(LB和RB的中垂線)---------------------------------------------------------

            //畫上最後一條midLine
            midLine = compute(cp1, cp2);
            midLine_original = compute(cp1, cp2);
            
            //修改端點(因為是最後一條所以只需修改Y座標較小的端點)
            if (midLine.startPoint.Y >= midLine.endPoint.Y) {
                midLine.endPoint = precrosspoint;
            } else {
                midLine.startPoint = precrosspoint;
            }
            midLine = Intersort_byX(midLine);          
            final.Add(midLine);            
            hyperLine.Add(midLine);

            //清除不需要的邊--------------------------------------------------------------------------------
            final = eliminate(final, hyperLine, edgeLeft, edgeRight);

            //在畫布中表示出Hyperline-----------------------------------------------------------------------
            if (StepMode) {
                pause();
                foreach (VoronoiEdge h in hyperLine) { canvas.DrawLine(Red_pen, h.startPoint, h.endPoint); }
                pause();
            }

            final = removeNeedlessLine(final);
            return final;
        }

        private VoronoiEdge Intersort_byX(VoronoiEdge edge)
        {
            PointF tmp;
            if (edge.startPoint.X > edge.endPoint.X || ((edge.startPoint.X == edge.endPoint.X) && (edge.startPoint.Y > edge.endPoint.Y)))
            {
                tmp = edge.startPoint;
                edge.startPoint = edge.endPoint;
                edge.endPoint = tmp;
            }            
            return edge;
        }

        //找出兩半邊最靠近的四個點(最靠近對側的最上和最下兩點)
        private PointF[] getCommonPoint(PointF[] convexHullLeft, PointF[] convexHullRight, PointF[] totalConvexHull)
        {
            //index = 0為左半邊的上切點，index = 1為右半邊的上切點 
            //index = 2為右半邊的下切點，index = 3為左半邊的下切點
            PointF[] Common = new PointF[4];

            bool check = false;//正在檢查的點所屬的ConvexHull，false代表左邊，ture代表右邊
            bool last = false;//上一個點所屬的ConvexHull，false代表左邊，ture代表右邊
            bool startSide = false;//紀錄起始的切點是屬於哪半邊，false代表左邊，ture代表右邊
                        
            int i = 0;//代表目前正在找的是哪個位置的切點
            int count = 0;//代表已經找到幾個切點
            int dataNum = totalConvexHull.Length;
            
            //如果所有點集合中的第一個點(也就是最左下的點)在左半邊
            if (IfExist(convexHullLeft, totalConvexHull[0])) {
                last = false; startSide = false;//起始點在左半邊
            }
            //如果所有點集合中的第一個點(也就是最左下的點)在右半邊
            else if (IfExist(convexHullRight, totalConvexHull[0])) {
                last = true; startSide = true;//起始點在右半邊
            }
            
            //以迴圈讀取點，直到發現點所屬的ConvexHull換邊，即代表此點與上一點為公切點
            //一次會找到兩個切點，一共要找四個切點，所以最終count會等於2
            while (true) {
                //循環搜尋pointAll中的點
                i = (i + 1) % dataNum;
                if (IfExist(convexHullLeft, totalConvexHull[i])) { check = false; }
                if (IfExist(convexHullRight, totalConvexHull[i])) { check = true; }

                //若正在找的點和上一個點屬於不同邊
                if (check != last)
                {
                    count += 1;
                    //若起始的切點在左邊
                    if (!startSide)
                    {                       
                        if (count == 1) {
                            //上一個點就是左半邊的上切點
                            Common[0] = totalConvexHull[(i - 1 + dataNum) % dataNum];
                            //正在檢查的這個點則是右半邊的上切點
                            Common[1] = totalConvexHull[i];
                        } else {
                            //上一個點就是右半邊的下切點
                            Common[2] = totalConvexHull[(i - 1 + dataNum) % dataNum];
                            //正在檢查的這個點則是左半邊的下切點
                            Common[3] = totalConvexHull[i];
                        }
                    }
                    //若起始的切點在右邊
                    else
                    {                        
                        if (count == 1) {
                            //上一個點就是右半邊的下切點
                            Common[2] = totalConvexHull[(i - 1 + dataNum) % dataNum];
                            //正在檢查的這個點則是左半邊的下切點
                            Common[3] = totalConvexHull[i];
                        } else {
                            //上一個點就是左半邊的上切點
                            Common[0] = totalConvexHull[(i - 1 + dataNum) % dataNum];
                            //正在檢查的這個點則是右半邊的上切點
                            Common[1] = totalConvexHull[i];
                        }
                    }                    
                }
                last = check;
                if (count == 2) { break; }
            }
            return Common;
        }

        //在array中搜尋點p
        private bool IfExist(PointF[] array, PointF p)
        {
            for (int i = 0; i < array.Length; i++) { if (array[i] == p) { return true; } }
            return false;
        }

        //判斷點p是否在edge線段上
        private bool OnEdge(VoronoiEdge edge, PointF p) {
            float minX = Math.Min(edge.startPoint.X, edge.endPoint.X);
            float maxX = Math.Max(edge.startPoint.X, edge.endPoint.X);
            float minY = Math.Min(edge.startPoint.Y, edge.endPoint.Y);
            float maxY = Math.Max(edge.startPoint.Y, edge.endPoint.Y);
            if (p.X >= minX && p.X <= maxX && p.Y >= minY && p.Y <= maxY)
            { return true; }
            else { return false; }
        }

        //克拉瑪公式
        private PointF Intersection(VoronoiEdge edge1,VoronoiEdge edge2) {
        
            float edge1X = edge1.endPoint.X - edge1.startPoint.X;
            float edge1Y = edge1.endPoint.Y - edge1.startPoint.Y;
            float edge2X = edge2.endPoint.X - edge2.startPoint.X;
            float edge2Y = edge2.endPoint.Y - edge2.startPoint.Y;
            float vectorX = edge2.startPoint.X - edge1.startPoint.X;
            float vectorY = edge2.startPoint.Y - edge1.startPoint.Y;

            PointF cross = new PointF();
            cross.X = edge1.startPoint.X + (edge1X * (vectorX * edge2Y - vectorY * edge2X)) / (edge1X * edge2Y - edge1Y * edge2X);
            cross.Y = edge1.startPoint.Y + (edge1Y * (vectorX * edge2Y - vectorY * edge2X)) / (edge1X * edge2Y - edge1Y * edge2X);

            return cross;
        }

        //判斷某條edge是屬於當前左右哪一半(1代表左邊，2代表右邊，3代表都不是)
        private int Belong(VoronoiEdge target, ArrayList edgeLeft, ArrayList edgeRight) {
            foreach (VoronoiEdge edge in edgeLeft) {
                if (edge.Equals(target)) { return 1; }
            }
            foreach (VoronoiEdge edge in edgeRight) {
                if (edge.Equals(target)) { return 2; }
            }
            return 3;
        }

        //步驟暫停
        private void pause() {
            while (pauseStep) { } pauseStep = true;
        }

        //步驟暫停
        private void pause_Convex()
        {
            while (pauseConvex) { } pauseConvex = true;
        }

        //清除不需要的邊
        private ArrayList eliminate(ArrayList final, ArrayList final_spare, ArrayList edgeLeft, ArrayList edgeRight)
        {
            for (int i = 0; i < final.Count; i++) {

                VoronoiEdge finaledge = (VoronoiEdge)final[i];

                int belong = Belong(finaledge, edgeLeft, edgeRight);//判斷這條finaledge是否屬於哪一半邊(1代表左邊，2代表右邊，3代表都不是)
                bool exceed = false;//判斷是否在其他線的範圍內

                for (int j = 0; j < final_spare.Count; j++) {

                    VoronoiEdge tmp = (VoronoiEdge)final_spare[j];
                    PointF finaledge_H = finaledge.getHighPoint(); //要檢查的線較高的端點
                    PointF finaledge_L = finaledge.getLowPoint(); //要檢查的線較低的端點
                    PointF tmp_H = tmp.getHighPoint(); //檢查基準線較高的端點
                    PointF tmp_L = tmp.getLowPoint(); //檢查基準線較低的端點

                    if (RangeOf(finaledge, tmp) == 1) { continue; }                                         
                    else {
                        //若左半邊voronoi出現在其他hyperline線段的右邊，則清除
                        if (belong == 1) {
                            if (RangeOf(finaledge,tmp) == 2 && crossproduct(tmp_L, tmp_H, finaledge_H) < 0){ exceed = true; break; }
                            else if (RangeOf(finaledge, tmp) == 3 && crossproduct(tmp_L, tmp_H, finaledge_L) < 0){ exceed = true; break; }
                            else if (RangeOf(finaledge, tmp) == 4 && crossproduct(tmp_L, tmp_H, finaledge_H) < 0){ exceed = true; break; }                            
                        }
                        //若右半邊voronoi出現在其他hyperline線段的左邊，則清除
                        else if (belong == 2) {
                            if (RangeOf(finaledge, tmp) == 2 && crossproduct(tmp_L, tmp_H, finaledge_H) > 0){ exceed = true; break; }
                            else if (RangeOf(finaledge, tmp) == 3 && crossproduct(tmp_L, tmp_H, finaledge_L) > 0){ exceed = true; break; }
                            else if (RangeOf(finaledge, tmp) == 4 && crossproduct(tmp_L, tmp_H, finaledge_H) > 0){ exceed = true; break; }                            
                        }
                    }
                }
                if (exceed) { final.RemoveAt(i); i = 0; }
            }
            return final;
        }

        //修改左右Voronoi和中垂線相交後的端點
        private Tuple<ArrayList,VoronoiEdge,PointF> modify_endpoint(ArrayList edgeSet,PointF cp,bool side,VoronoiEdge crossLine,PointF crosspoint,VoronoiEdge midLine_original) {
            
            //找下一個檢查點
            if (crossLine.parentHigh.Equals(cp)) { cp = crossLine.parentLow; }
            else { cp = crossLine.parentHigh; }

            PointF midLowpoint = midLine_original.getLowPoint();

            for (int i = 0; i < edgeSet.Count; i++) {
                VoronoiEdge tmp = (VoronoiEdge)edgeSet[i];

                //如果這條VoronoiEdge和交線是同一條
                if (crossLine.Equals(tmp)) {

                    float cross = crossproduct(midLowpoint, crosspoint, crossLine.startPoint);
                    
                    //判斷點在交線的哪一側                            
                    if (midLowpoint.Y < crosspoint.Y) {
                        if (cross < 0) {
                            if (side == false) { crossLine.startPoint = crosspoint; } 
                            else { crossLine.endPoint = crosspoint; }
                        } else {
                            if (side == false) { crossLine.endPoint = crosspoint; }
                            else { crossLine.startPoint = crosspoint; }
                        }
                    }
                    else if (midLowpoint.Y == crosspoint.Y) {
                        if (cross < 0) {
                            crossLine.startPoint = crosspoint;
                        } else {
                            crossLine.endPoint = crosspoint;
                        }
                    }
                    tmp.startPoint = crossLine.startPoint;
                    tmp.endPoint = crossLine.endPoint;
                    tmp = Intersort_byX(tmp);
                    edgeSet[i] = tmp;                    
                    break;
                }
            }           
            return Tuple.Create<ArrayList,VoronoiEdge,PointF>(edgeSet,crossLine,cp);
        }
        
        //判斷某個點是否為某條edge的parent
        private char parentofedge(VoronoiEdge edge, PointF point) {
            if (edge.parentHigh.Equals(point)) { return 'H';}
            else if (edge.parentLow.Equals(point)) { return 'L'; }
            else { return 'N'; }
        }

        //判斷某條edge是否在另一條的範圍中
        private int RangeOf(VoronoiEdge checkEdge,VoronoiEdge targetEdge){
            
            if (checkEdge.getLowPoint().Y > targetEdge.getHighPoint().Y) { return 1; }
            else if (checkEdge.getHighPoint().Y < targetEdge.getLowPoint().Y) { return 1; }
            else if (checkEdge.getLowPoint().Y < targetEdge.getLowPoint().Y && checkEdge.getHighPoint().Y > targetEdge.getHighPoint().Y) { return 1; }
            else if (checkEdge.getLowPoint().Y > targetEdge.getLowPoint().Y && checkEdge.getHighPoint().Y < targetEdge.getHighPoint().Y) { return 2; }
            else if (checkEdge.getLowPoint().Y > targetEdge.getLowPoint().Y && checkEdge.getHighPoint().Y > targetEdge.getHighPoint().Y) { return 3; }
            else if (checkEdge.getLowPoint().Y < targetEdge.getLowPoint().Y && checkEdge.getHighPoint().Y < targetEdge.getHighPoint().Y) { return 4; }
            else { return 5; }
        }

        //去除看不見的線段(超出畫布範圍)
        private bool invisibleEdge(VoronoiEdge edge) {
            if (edge.startPoint.X < 0 && edge.endPoint.X < 0) {
                return true;
            }else if (edge.startPoint.X > 700 && edge.endPoint.X > 700) {
                return true;
            }else if(edge.startPoint.Y < 0 && edge.endPoint.Y < 0){
                return true;
            }else if (edge.startPoint.Y > 700 && edge.endPoint.Y > 700){
                return true;
            }else{
                return false;
            }
        }

        //去除重複和長度為0的線段
        private ArrayList removeNeedlessLine(ArrayList arrayList) {
            
            ArrayList newSet = new ArrayList();
            //移除重複的線段
            for (int i = 0; i < arrayList.Count; i++) {
                VoronoiEdge e1 = (VoronoiEdge)arrayList[i];
                if (newSet.Count != 0){
                    bool find = false;
                    for (int j = 0; j < newSet.Count; j++){
                        VoronoiEdge e2 = (VoronoiEdge)newSet[j];
                        if (e1.startPoint == e2.startPoint && e1.endPoint == e2.endPoint){
                            find = true; break;
                        }
                    }
                    if (find == false){ newSet.Add(e1); }
                } else { newSet.Add(e1); }
            }
            //移除長度為0的線段
            for (int i = 0; i < newSet.Count; i++) {
                VoronoiEdge e = (VoronoiEdge)newSet[i];
                if (e.startPoint == e.endPoint) {
                    newSet.RemoveAt(i);
                }
            }
            return newSet;
        }

        //儲存線段到listView_inputedLine中
        private void store_line(ArrayList arraylist) {
            foreach (VoronoiEdge edge in arraylist)
            {
                if (invisibleEdge(edge) == false)
                {                    
                    canvas.DrawLine(Red_pen, edge.startPoint, edge.endPoint);
                    int x1 = (int)Math.Round(edge.startPoint.X);
                    int y1 = (int)Math.Round(edge.startPoint.Y);
                    int x2 = (int)Math.Round(edge.endPoint.X);
                    int y2 = (int)Math.Round(edge.endPoint.Y);

                    string[] coordinate = { x1.ToString(), y1.ToString(), x2.ToString(), y2.ToString() };
                    var AddLine = new ListViewItem(coordinate);
                    listView_inputedLine.Items.Add(AddLine);
                }
            }
            sort_line();
        }
    }
}
