﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace Voronoi
{
    class VoronoiEdge
    {
        public PointF startPoint;
        public PointF endPoint;
        public PointF parentHigh;
        public PointF parentLow;        

        public VoronoiEdge() {

            startPoint = new PointF();
            endPoint = new PointF();
        }

        public VoronoiEdge(PointF start, PointF end, PointF parent1, PointF parent2) {
            
            //形成中垂線的兩點以Y座標排序
            if (parent1.Y <= parent2.Y)
            {
                parentHigh = parent2;
                parentLow = parent1;
            }
            else {
                parentHigh = parent1;
                parentLow = parent2;
            }

            //中垂線的起點和終點以X座標排序
            if (start.X < end.X || ((start.X == end.X) && (start.Y < end.Y)))
            {
                startPoint = start;
                endPoint = end;
            }
            else {
                startPoint = end;
                endPoint = start;
            }
        }

        //找出起點跟終點哪一點比較低
        public PointF getLowPoint()
        {
            float min = Math.Min(startPoint.Y, endPoint.Y);

            if (startPoint.Y == min && endPoint.Y != min)
            {
                return startPoint;
            }
            else {
                return endPoint;
            }            
        }

        //找出起點跟終點哪一點比較高
        public PointF getHighPoint()
        {
            float max = Math.Max(startPoint.Y, endPoint.Y);

            if (startPoint.Y == max && endPoint.Y != max)
            {
                return startPoint;
            }
            else {
                return endPoint;
            }
        }    
    }
}
